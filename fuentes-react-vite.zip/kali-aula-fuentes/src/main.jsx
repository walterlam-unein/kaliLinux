import React from 'react';
import { createRoot } from 'react-dom/client';
import { Desktop } from './os/Desktop.jsx';
import './styles.css';
import './learning.css';
import './os/desktop.css';

const root=document.getElementById('root');
if(root)createRoot(root).render(<Desktop/>);
