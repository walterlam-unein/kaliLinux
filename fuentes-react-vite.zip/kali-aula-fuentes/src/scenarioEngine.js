import { CANDIDATES } from './content.js';
import { MECHANISMS } from './learning.js';

export function normalizeScenario(id,input={}){const m=MECHANISMS[id];if(!m)throw new Error('Taller desconocido.');return Object.fromEntries(m.fields.map(f=>[f.key,f.options.some(o=>o[0]===input[f.key])?input[f.key]:m.defaults[f.key]]));}
export function scenarioLabel(id,c){const m=MECHANISMS[id];return m.fields.filter(f=>!(id==='session'&&f.key==='factor'&&c.channel!=='proxy')).map(f=>f.options.find(o=>o[0]===c[f.key])?.[1]).join(' · ');}
export function dictionaryList(c){return c.order==='first'?[CANDIDATES[4],...CANDIDATES.slice(0,4)]:[...CANDIDATES];}
const outcome=(tone,title,detail,asset,access,trace,extra={})=>({tone,title,detail,asset,access,trace,done:true,...extra});

// Reglas de aula, sin red, solicitudes de acceso ni lectura de cookies reales.
export function evaluateScenario(id,input,cursor=1){
 const c=normalizeScenario(id,input);
 if(id==='phishing'){
  const prefix=c.tls==='yes'?'La conexión cifra los datos hacia el destino elegido.':'El modelo utiliza un canal sin cifrar.';
  if(c.decision==='leave')return outcome('safe','La muestra no se entregó','Luna salió antes de enviarla. Este intento no obtiene sus credenciales.','Ninguna credencial recibida','No concedido',[prefix,'La persona no envía la muestra.','El impostor no recibe el secreto.']);
  if(c.destination==='known')return outcome(c.tls==='yes'?'safe':'caution','La muestra llegó al destino conocido','El destinatario del formulario es el servicio ficticio previsto. Si eliges HTTP, el transporte sigue siendo inseguro: aquí solo se comprueba la suplantación del destino.','Ninguna muestra entregada al impostor','No se simula un acceso ajeno',[prefix,'El dominio corresponde al servicio de aula.','Este caso no entrega datos a una página impostora.']);
  return outcome('risk','Muestra entregada al impostor','La copia visual logró que Luna enviara el secreto al destino equivocado. Tener HTTPS no cambia al destinatario.','luna.crea / Luna!26','Todavía no comprobado',[prefix,'La página pertenece al dominio aula.invalid.','La contraseña queda expuesta; entrar en la cuenta exige superar sus verificaciones.']);
 }
 if(id==='stuffing'){
  if(c.reuse==='no')return outcome('safe','El par filtrado no coincide','La contraseña social es distinta a la de PixelShop. La comprobación de la clave detiene este intento.','El par antiguo de PixelShop','Rechazado',['Se presenta el par filtrado.','La clave social no coincide.','No se crea una sesión.']);
  if(c.mfa==='on')return outcome('safe','Falta el segundo factor','La clave es correcta, pero el impostor no tiene la prueba independiente que exige este modelo.','Contraseña válida conocida','Pendiente: no concedido',['El par coincide.','Se exige un segundo factor.','Sin esa prueba, no se completa el acceso.']);
  return outcome('risk','Sesión concedida por reutilización','El par conocido funciona en ambos servicios y no se exige otra prueba.','Par válido y nueva sesión','Concedido',['El par procede de otra tienda.','Coincide con la cuenta social.','Se concede acceso en el modelo.']);
 }
 if(id==='dictionary'){
  const list=dictionaryList(c),secret=c.target==='listed'?'Luna!26':'Mapa-cielo-nube-72',limit=Number(c.limit),max=Math.max(0,Math.min(5,Math.floor(Number(cursor)||0))),trials=[];
  let state='running';
  for(let i=0;i<max;i++){const hit=list[i]===secret;trials.push({candidate:list[i],hit});if(hit){state='hit';break;}if(limit&&trials.length>=limit){state='limit';break;}if(i===list.length-1)state='empty';}
  const extra={trials,list,done:state!=='running',state};
  if(state==='hit')return outcome('risk','La candidata coincidió',`La coincidencia apareció en el intento ${trials.length}. Un límite posterior no habría detenido este acierto.`,secret,'Concedido',trials.map((t,i)=>`${i+1}. ${t.candidate}: ${t.hit?'coincide':'no coincide'}`),extra);
  if(state==='limit')return outcome('safe','Pausa de intentos alcanzada',`La ronda se detuvo después de ${trials.length} fallos. No demuestra que la clave sea imposible de adivinar.`,'Ninguna contraseña confirmada','Rechazado',trials.map((t,i)=>`${i+1}. ${t.candidate}: no coincide`),extra);
  if(state==='empty')return outcome('safe','Lista agotada sin coincidencia','Esta lista no contiene el secreto elegido. Otra lista sería una prueba diferente.','Ninguna contraseña confirmada','Rechazado',trials.map((t,i)=>`${i+1}. ${t.candidate}: no coincide`),extra);
  return outcome('waiting','Todavía no hay coincidencia','Pulsa «Probar siguiente candidata» para avanzar un intento.','Ninguna contraseña confirmada','No concedido',trials.map((t,i)=>`${i+1}. ${t.candidate}: no coincide`),extra);
 }
 if(id==='session'){
  if(c.channel==='tls')return outcome('safe','El observador no obtiene el token','Con HTTPS válido hacia el origen correcto, observar esa red no permite leer el token en este escenario.','Contenido cifrado','No concedido',['Luna se conecta al origen correcto.','El observador solo ve contenido cifrado.','No dispone de un token para reutilizar.']);
  if(c.channel==='proxy'&&c.factor==='passkey')return outcome('safe','El origen impostor no completa la autenticación','En este caso de phishing, la passkey está vinculada al servicio legítimo y no autentica ese origen impostor. Esto no vuelve invulnerable al dispositivo.','No se obtiene una sesión por este engaño','No concedido',['Luna está en un origen distinto.','La passkey del servicio no autentica ese origen.','El intermediario no recibe una sesión de este acceso.']);
  const exposure=c.channel==='http'?'El token viaja en claro por el transporte inseguro.':'Luna entrega la clave y el código al intermediario; este los retransmite y obtiene una copia de la sesión en el modelo.';
  if(c.revoked==='yes')return outcome('safe','La copia del token fue rechazada','El token quedó expuesto, pero el servidor ya lo revocó. La exposición y la validez son condiciones distintas.','DEMO-SESION-042 · copia revocada','Rechazado',[exposure,'Se presenta una copia del token.','El servidor la rechaza por estar revocada.']);
  return outcome('risk','Sesión suplantada con un token vigente','La copia permite representar la sesión de Luna en este modelo, que no exige una verificación adicional para reutilizarla.','DEMO-SESION-042 · vigente','Concedido',[exposure,'La copia se usa como identificador de sesión.','El servidor todavía la acepta.']);
 }
 if(id==='recovery'){
  if(c.mail==='no')return outcome('safe','El impostor no tiene el enlace','Solicitar la recuperación no basta. El mensaje solo llega al buzón que controla Luna.','Ningún enlace recibido','No restablecido',['Se solicita recuperar el acceso.','El enlace llega al buzón de Luna.','El impostor no puede presentar ese enlace.']);
  if(c.token!=='valid')return outcome('safe','Enlace rechazado',c.token==='expired'?'El enlace caducó. El servicio rechaza su uso aunque alguien controle el correo.':'El enlace era de un solo uso y ya fue consumido. No debe servir de nuevo.','Enlace inválido','No restablecido',['El impostor lee el correo.','Presenta un enlace que ya no es válido.','La validación detiene el cambio.']);
  if(c.factor==='on')return outcome('safe','Se exige otra prueba de identidad','El buzón y el enlace no bastan: falta una prueba independiente que el impostor no controla.','Enlace vigente, prueba adicional ausente','No restablecido',['El enlace está vigente.','Se exige una prueba independiente.','Sin ella, no se cambia el acceso.']);
  return outcome('risk','Restablecimiento permitido','En este flujo débil, el enlace vigente del correo comprometido es suficiente aunque se desconozca la clave anterior.','Enlace de restablecimiento válido','Restablecido',['El impostor controla el buzón.','El enlace vigente se acepta.','El servicio permite cambiar el acceso.']);
 }
 throw new Error('Taller desconocido.');
}
