import React,{useState} from 'react';
import { Icon } from './components/UI.jsx';
import { MECHANISMS } from './learning.js';

export function Mechanism({workshop:w}){
 const [selected,setSelected]=useState(0),m=MECHANISMS[w.id];
 return <details className="mechanism"><summary><Icon name={w.icon} size={20}/><span><b>Cómo puede comprometerse esta cuenta</b><small>{m.focus}</small></span><span className="disclosure-label">Explorar explicación</span></summary><div className="mechanism-body"><p className="mechanism-definition">{w.concept}</p><div className="mechanism-facts"><div><span>PUNTO DE PARTIDA</span><p>{m.starting}</p></div><div><span>QUÉ SE OBTIENE</span><p>{m.asset}</p></div><div><span>CUÁNDO PUEDE FUNCIONAR</span><p>{m.condition}</p></div></div><div className="mechanism-sequence" role="group" aria-label="Explorar el mecanismo">{m.chain.map(([title],i)=><button key={title} className={selected===i?'active':''} aria-pressed={selected===i} onClick={()=>setSelected(i)}><span>{i+1}</span>{title}<Icon name="arrow" size={15}/></button>)}</div><p className="mechanism-detail" aria-live="polite"><b>{m.chain[selected][0]}.</b> {m.chain[selected][1]}</p><p className="model-limit"><Icon name="info" size={17}/>{m.limit}</p><a className="source-link" href={w.source} target="_blank" rel="noreferrer">Ampliar con OWASP <Icon name="arrow" size={14}/></a></div></details>;
}
