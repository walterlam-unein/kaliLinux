export const CONFIG_KEY='acceso-lab-config-v3';
export const DEFAULT_CONFIG={courseName:'Programación · Bachillerato',teacherName:'',projector:false,showKali:true,showExperiments:true};
export function cleanConfiguration(input={}){
 return {courseName:typeof input.courseName==='string'?input.courseName.trim().slice(0,80):DEFAULT_CONFIG.courseName,teacherName:typeof input.teacherName==='string'?input.teacherName.trim().slice(0,100):'',projector:input.projector===true,showKali:input.showKali!==false,showExperiments:input.showExperiments!==false};
}
export function readConfiguration(storage,base={}){try{const saved=storage?.getItem(CONFIG_KEY);return cleanConfiguration({...base,...(saved?JSON.parse(saved):{})});}catch{return cleanConfiguration(base);}}
export function configurationFile(value){return '// Ajustes de aula. Sustituye el config.js junto a index.html.\nwindow.LAB_CONFIG = '+JSON.stringify(cleanConfiguration(value),null,2)+';\n';}
