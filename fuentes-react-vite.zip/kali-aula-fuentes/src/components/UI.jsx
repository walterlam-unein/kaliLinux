import React from 'react';

const paths = {
 lock: 'M6 10V7a6 6 0 0 1 12 0v3M5 10h14v12H5zM12 15v3',
 shield: 'M12 2l8 3v6c0 5-8 10-8 10S4 16 4 11V5zM8 11l3 3 5-6',
 link: 'M10 13a5 5 0 0 0 7 0l3-3a5 5 0 0 0-7-7l-2 2M14 11a5 5 0 0 0-7 0l-3 3a5 5 0 0 0 7 7l2-2',
 layers: 'M12 2L2 7l10 5 10-5zM2 12l10 5 10-5M2 17l10 5 10-5',
 key: 'M15 3a6 6 0 1 1-4 10L3 21H1v-4l8-8a6 6 0 0 1 6-6zM16 7h.01',
 network: 'M9 2h6v6H9zM2 16h6v6H2zM16 16h6v6h-6zM12 8v5M5 16v-3h14v3',
 refresh: 'M20 7a9 9 0 1 0 1 9M20 2v6h-6',
 play: 'M7 3l14 9-14 9z', pause: 'M8 4v16M16 4v16', step: 'M4 4l12 8-12 8zM20 4v16',
 arrow: 'M5 12h14M13 6l6 6-6 6', check: 'M4 12l5 5L20 6', close: 'M5 5l14 14M19 5L5 19',
 eye: 'M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12zM15 12a3 3 0 1 1-6 0 3 3 0 0 1 6 0',
 settings: 'M4 6h16M4 12h16M4 18h16M8 3v6M16 9v6M10 15v6',
 book: 'M2 3h7l3 2 3-2h7v17h-7l-3 2-3-2H2zM12 5v17',
 code: 'M8 5l-7 7 7 7M16 5l7 7-7 7M14 2l-4 20',
 up: 'M6 14l6-6 6 6', down: 'M6 10l6 6 6-6',
 info: 'M12 16v-5M12 7h.01M22 12a10 10 0 1 1-20 0 10 10 0 0 1 20 0',
 mail: 'M2 4h20v16H2zM2 5l10 8L22 5', globe: 'M22 12a10 10 0 1 1-20 0 10 10 0 0 1 20 0M2 12h20M12 2c6 6 6 14 0 20-6-6-6-14 0-20',
 monitor: 'M2 3h20v14H2zM12 17v5M7 22h10',
 heart: 'M12 21L3 12C-3 5 6-1 12 6c6-7 15-1 9 6z', comment: 'M21 11a9 9 0 0 1-9 9H3l1-5a9 9 0 1 1 17-4z',
 save: 'M5 2h14v20l-7-5-7 5z', print: 'M6 8V2h12v6M6 17H2V8h20v9h-4M6 14h12v8H6z',
 terminal: 'M3 5l6 6-6 6M12 19h9', sun:'M12 3v2M12 19v2M3 12h2M19 12h2M5 5l2 2M17 17l2 2M5 19l2-2M17 7l2-2M16 12a4 4 0 1 1-8 0 4 4 0 0 1 8 0'
};
export function Icon({ name = 'shield', size = 20, ...props }) { return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" {...props}><path d={paths[name] || paths.shield} /></svg>; }
export function Avatar({ name = 'L', size = '', color = 0 }) { return <span className={`avatar ${size} c${color}`} aria-hidden="true"><span>{name.slice(0, 1).toUpperCase()}</span></span>; }
