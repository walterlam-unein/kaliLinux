import React from 'react';
import { Avatar,Icon } from './UI.jsx';

export function SocialFrame({children,url='https://social.aula.test / demostración',mode='Datos ficticios',sceneKey}){
 return <section className="social-shell" aria-label="Simulador de red social"><div className="simulation-banner"><span><i/>INSTAGRAM · MAQUETA EDUCATIVA</span><span>{mode}</span></div><div className="address-bar"><Icon name="globe" size={15}/><span>{url}</span></div><div className="social-body"><aside className="social-sidebar" aria-hidden="true"><span className="instagram-word">Instagram</span><div><Icon name="monitor"/>Inicio</div><div><Icon name="globe"/>Explorar</div><div><Icon name="mail"/>Mensajes</div><div><Icon name="heart"/>Actividad</div><div className="side-profile"><Avatar name="Luna"/>luna.crea</div><small>Perfil de muestra</small></aside><div className="social-stage" key={sceneKey}>{children}</div></div></section>;
}
