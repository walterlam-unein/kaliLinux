import { WORKSHOPS } from '../content.js';
import { MECHANISMS } from '../learning.js';

export const LAB_ROOT='/root/laboratorios';
export const INSTALL_STEPS=[
 ['Comprueba Docker','Escribe el comando en la terminal del equipo anfitrión y pulsa Enter.','docker --version','Docker administra contenedores; una imagen es la base para crear uno.'],
 ['Obtén la imagen de Kali','Descarga la imagen oficial dentro de esta simulación.','docker pull kalilinux/kali-rolling','pull obtiene una imagen. Todavía no crea un contenedor.'],
 ['Crea el contenedor','Ponle el nombre kali-aula y deja una consola disponible.','docker run -dit --name kali-aula kalilinux/kali-rolling bash','run crea y arranca el contenedor. -dit combina segundo plano, entrada interactiva y terminal.'],
 ['Entra en Kali','Abre una shell dentro del contenedor. El prompt cambiará a root@kali-aula.','docker exec -it kali-aula bash','exec inicia un proceso dentro de un contenedor que ya existe.'],
 ['Actualiza el índice','Consulta el catálogo de paquetes antes de instalar el escritorio.','apt update','Este paso actualiza los índices; no actualiza por sí solo todos los paquetes.'],
 ['Instala el escritorio','Añade el metapaquete del entorno Xfce. La salida y la instalación son simuladas.','apt install -y kali-desktop-xfce','La imagen básica de Kali no trae un escritorio completo.'],
 ['Abre la sesión gráfica','Ejecuta el lanzador didáctico. Después podrás abrir terminal, archivos y navegador.','aula escritorio','aula es una herramienta inventada para esta página. En un contenedor real también se necesita configurar un servidor gráfico o un acceso remoto; instalar Xfce no abre un escritorio por sí solo.']
];
export const LAB_TASKS={
 phishing:[
  ['Lee el mensaje','Abre el mensaje de soporte y observa la dirección completa.','cat mensaje.txt','La apariencia y la urgencia no demuestran quién recibe tus datos.','read'],
  ['Identifica al destinatario','Escribe el dominio principal que controla el enlace.','aula dominio aula.invalid','El enlace es social.aula.test.validacion.aula.invalid. El dominio final es aula.invalid.','domain'],
  ['Observa la entrega','Ejecuta la prueba inicial. El navegador mostrará quién recibió la muestra.','aula phishing','La configuración inicial envía datos ficticios al destino impostor.','vulnerable'],
  ['Cambia la decisión','Abre politica.json, cambia "decision": "send" por "decision": "leave" y guarda el archivo.','mousepad politica.json','El editor modifica el archivo virtual. Guardar es necesario para aplicar el cambio.','defense'],
  ['Comprueba la defensa','Repite la prueba y verifica que ya no se entregó la muestra.','aula phishing','Se usa el mismo mensaje, pero Luna sale antes de enviar datos.','protected']
 ],
 stuffing:[
  ['Lee la filtración','Consulta el par que perdió la tienda ficticia PixelShop.','cat filtracion.csv','El origen de la contraseña es una filtración previa en otro servicio.','read'],
  ['Prueba el par conocido','Escribe el usuario y la clave de la muestra. Observa la respuesta del servicio.','aula acceso luna.crea Luna!26','Son los datos de la tienda: no se está adivinando una contraseña nueva.','vulnerable'],
  ['Configura una clave única','Abre politica.json. Cambia "reuse": "yes" por "reuse": "no" y guarda.','mousepad politica.json','La cuenta social pasará a usar Mapa-cielo-nube-72. El par filtrado no cambia.','defense'],
  ['Repite exactamente el intento','Vuelve a escribir el mismo par filtrado y revisa por qué se rechaza.','aula acceso luna.crea Luna!26','En este segundo caso, la clave de la cuenta social ya es distinta.','protected']
 ],
 dictionary:[
  ['Examina la lista','Lee las cinco candidatas de aula. Cada línea contiene una posibilidad.','cat candidatas.txt','La cuenta de muestra tiene Luna!26. Inicialmente está al final de la lista.','read'],
  ['Ejecuta la primera ronda','Indica el archivo que contiene las candidatas. Observa en qué intento se encuentra la clave.','aula diccionario candidatas.txt','La ronda inicial no tiene límite y se detiene en cuanto encuentra una coincidencia.','vulnerable'],
  ['Añade un límite','Abre politica.json. Cambia "limit": "0" por "limit": "3" y guarda.','mousepad politica.json','Solo cambia el límite. Conserva el secreto y el orden de candidatas para comparar.','defense'],
  ['Comprueba la pausa','Repite la búsqueda y observa que se detiene antes de la quinta candidata.','aula diccionario candidatas.txt','Tras tres fallos esta ronda termina; otro clic no continúa la ronda detenida.','protected']
 ],
 session:[
  ['Observa HTTPS','Consulta el tráfico cifrado de la conexión al origen correcto.','aula trafico https','El observador no obtiene el token de una conexión TLS válida por estar en la misma red.','tls'],
  ['Compara con HTTP','Consulta ahora el transporte inseguro. Lee el token de la cabecera Cookie.','aula trafico http','Es una captura inventada de un servicio inseguro, no el transporte real de Instagram.','read'],
  ['Presenta el token','Escribe el identificador observado y comprueba si el servidor lo acepta.','aula sesion DEMO-SESION-042','La contraseña no se vuelve a introducir. El token representa una sesión ya iniciada.','vulnerable'],
  ['Revoca la sesión','Invalida ese token en el servidor del modelo.','aula revocar','Revocar cambia la validez en el servidor; no borra las copias que alguien tenga.','defense'],
  ['Reutiliza la misma copia','Prueba otra vez el mismo identificador. Observa el rechazo.','aula sesion DEMO-SESION-042','La copia existe, pero ha dejado de ser válida.','protected']
 ],
 recovery:[
  ['Solicita recuperación','Pide un enlace para la cuenta ficticia. Se generará un correo local.','aula recuperar luna.crea','El escenario inicial supone que el impostor ya controla el buzón de recuperación.','requested'],
  ['Lee el correo','Abre el archivo recibido y localiza el token de un solo uso.','cat correo-recuperacion.txt','Solicitar un enlace no concede acceso: hay que poseerlo y presentar uno válido.','read'],
  ['Usa el enlace vigente','Escribe el token que aparece en el correo para comprobar el flujo débil.','aula restablecer {token}','En el primer caso el correo basta. El token quedará consumido después del cambio.','vulnerable'],
  ['Refuerza la recuperación','Abre politica.json. Cambia "factor": "off" por "factor": "on" y guarda.','mousepad politica.json','La nueva prueba no depende de ese mismo buzón y el impostor no la tiene.','defense'],
  ['Solicita un enlace nuevo','Genera otro correo: el token anterior ya se utilizó.','aula recuperar luna.crea','La comparación debe usar un enlace nuevo, no uno consumido.','requestedAgain'],
  ['Comprueba la nueva barrera','Lee el correo actualizado y usa su nuevo token. Observa la verificación adicional.','aula restablecer {token}','Esta vez un enlace vigente no basta para restablecer el acceso.','protected']
 ]
};
export function baseFiles(id){
 const w=WORKSHOPS.find(w=>w.id===id),m=MECHANISMS[id],config={...m.defaults};
 if(id==='dictionary'){config.limit='0';delete config.order;}
 if(id==='session'){delete config.channel;delete config.revoked;}
 const files={
  'LEEME.txt':`${w.name}\n${w.concept}\n\nCondición del caso: ${m.condition}\n\n${m.limit}\n\nLos comandos aula pertenecen solo a este simulador.\n`,
  'politica.json':JSON.stringify(config,null,2)+'\n',
  'evidencias.log':'REGISTRO DEL SERVICIO DE AULA\nTodavía no hay pruebas.\n'
 };
 if(id==='phishing')files['mensaje.txt']='De: soporte_verificacion\nPara: luna.crea\nAsunto: Verifica tu cuenta en 10 minutos\n\nConfirma tus datos para evitar una suspensión.\nDestino: https://social.aula.test.validacion.aula.invalid/login\n\nEste es un mensaje ficticio del laboratorio.\n';
 if(id==='stuffing')files['filtracion.csv']='origen,usuario,contrasena\nPixelShop,luna.crea,Luna!26\n';
 if(id==='dictionary')files['candidatas.txt']='123456\npassword\nqwerty\nluna2026\nLuna!26\n';
 if(id==='session'){
  files['captura-https.txt']='CAPTURA SIMULADA · ORIGEN CORRECTO\nTLS Application Data: [contenido cifrado]\nEl token no es legible para el observador de red.\n';
  files['captura-http.txt']='CAPTURA SIMULADA · TRANSPORTE INSEGURO\nGET /perfil HTTP/1.1\nHost: social.aula.test\nCookie: sesion=DEMO-SESION-042\n\nEste ejemplo HTTP no describe el transporte real de Instagram.\n';
 }
 if(id==='recovery')files['correo-recuperacion.txt']='Bandeja vacía. Solicita un enlace con aula recuperar luna.crea\n';
 return files;
}
export function newLab(id){return {files:baseFiles(id),done:[],result:null,runs:[],revoked:false,exposed:false,issued:0,consumed:false,token:''};}
export function completeTask(lab,key){if(!lab.done.includes(key))lab.done.push(key);}
export function taskIndex(id,lab){const index=LAB_TASKS[id].findIndex(t=>!lab.done.includes(t[4]));return index<0?LAB_TASKS[id].length:index;}
export function taskInstruction(id,lab){const i=taskIndex(id,lab),step=LAB_TASKS[id][i];return step?{title:step[0],text:step[1],command:step[2].replace('{token}',lab.token||'DEMO-RESET-017'),hint:step[3],index:i}:null;}
