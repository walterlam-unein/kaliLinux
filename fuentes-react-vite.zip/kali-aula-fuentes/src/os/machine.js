import { WORKSHOPS,BY_ID } from '../content.js';
import { MECHANISMS } from '../learning.js';
import { evaluateScenario } from '../scenarioEngine.js';
import { LAB_ROOT,LAB_TASKS,newLab,completeTask,taskIndex } from './labFiles.js';

export const MACHINE_KEY='acceso-lab-desktop-v1';
export function newMachine(){return {version:1,stage:0,context:'host',ownerId:null,activeLab:'phishing',cwd:'/home/estudiante',labs:Object.fromEntries(WORKSHOPS.map(w=>[w.id,newLab(w.id)])),history:[],entries:[],sequence:0};}
export function loadMachine(storage){
 try{const text=storage?.getItem(MACHINE_KEY);if(!text)return newMachine();if(text.length>2_000_000)throw new Error();const raw=JSON.parse(text),m=newMachine();
  if(raw.version!==1||!Number.isInteger(raw.stage)||raw.stage<0||raw.stage>7)throw new Error();
  m.stage=raw.stage;m.context=['host','container'].includes(raw.context)?raw.context:'host';m.ownerId=typeof raw.ownerId==='string'?raw.ownerId:null;
  m.activeLab=BY_ID[raw.activeLab]?raw.activeLab:'phishing';m.cwd=typeof raw.cwd==='string'&&directories().includes(raw.cwd)?raw.cwd:(m.stage===7?`${LAB_ROOT}/${m.activeLab}`:'/home/estudiante');
  for(const w of WORKSHOPS){const saved=raw.labs?.[w.id];if(!saved)continue;const lab=newLab(w.id);
   for(const name of Object.keys(lab.files)){if(typeof saved.files?.[name]==='string'&&saved.files[name].length<=15000)lab.files[name]=saved.files[name];}
   lab.done=Array.isArray(saved.done)?saved.done.filter(x=>LAB_TASKS[w.id].some(t=>t[4]===x)):[];
   lab.revoked=saved.revoked===true;lab.exposed=saved.exposed===true;lab.issued=Number.isInteger(saved.issued)?Math.max(0,Math.min(1000,saved.issued)):0;lab.consumed=saved.consumed===true;lab.token=/^DEMO-RESET-\d{3,4}$/.test(saved.token||'')?saved.token:'';
   if(saved.result&&typeof saved.result.title==='string'&&Array.isArray(saved.result.trace))lab.result=saved.result;
   lab.runs=Array.isArray(saved.runs)?saved.runs.slice(-10).filter(x=>typeof x.title==='string'):[];m.labs[w.id]=lab;
  }
  m.history=Array.isArray(raw.history)?raw.history.filter(x=>typeof x==='string').slice(-100):[];
  m.entries=Array.isArray(raw.entries)?raw.entries.filter(x=>typeof x.input==='string'&&Array.isArray(x.output)&&x.output.every(y=>typeof y==='string')).slice(-100):[];m.sequence=Number(raw.sequence)||0;return m;
 }catch{return newMachine();}
}
export function directories(){return ['/','/root',LAB_ROOT,'/home','/home/estudiante',...WORKSHOPS.map(w=>`${LAB_ROOT}/${w.id}`)];}
export function pathFor(machine,value='.'){
 const raw=value.startsWith('/')?value:value==='~'?'/root':value.startsWith('~/')?'/root/'+value.slice(2):`${machine.cwd}/${value}`;const parts=[];
 for(const p of raw.split('/')){if(!p||p==='.')continue;if(p==='..')parts.pop();else parts.push(p);}return '/'+parts.join('/');
}
export function resolveFile(machine,value){const path=pathFor(machine,value);const match=path.match(/^\/root\/laboratorios\/([^/]+)\/([^/]+)$/);if(!match||!machine.labs[match[1]]||!Object.hasOwn(machine.labs[match[1]].files,match[2]))return null;return {path,labId:match[1],name:match[2],text:machine.labs[match[1]].files[match[2]]};}
export function selectLab(machine,id){if(!BY_ID[id]||machine.stage<7)return machine;return {...machine,activeLab:id,cwd:`${LAB_ROOT}/${id}`,context:'container'};}
export function readVirtualFile(machine,path){const next=structuredClone(machine),file=resolveFile(next,path);if(!file)return {machine,error:'No existe ese archivo virtual.'};const lab=next.labs[file.labId];if(['mensaje.txt','filtracion.csv','candidatas.txt'].includes(file.name)||file.name==='correo-recuperacion.txt'&&lab.issued>0)completeTask(lab,'read');return {machine:next,file};}
export function validatePolicy(id,text){let data;try{data=JSON.parse(text);}catch{throw new Error('JSON inválido: revisa comillas, comas y llaves antes de guardar.');}const fields=MECHANISMS[id].fields.filter(f=>!(id==='dictionary'&&f.key==='order')&&!(id==='session'&&['channel','revoked'].includes(f.key)));if(!data||Array.isArray(data)||typeof data!=='object')throw new Error('La política debe ser un objeto JSON.');for(const f of fields)if(!f.options.some(o=>o[0]===data[f.key]))throw new Error(`Valor inválido para ${f.key}. Usa: ${f.options.map(o=>o[0]).join(', ')}.`);if(Object.keys(data).some(key=>!fields.some(f=>f.key===key)))throw new Error('La política contiene una opción desconocida.');return data;}
export function saveVirtualFile(machine,path,text){
 const next=structuredClone(machine),file=resolveFile(next,path);if(!file)throw new Error('Archivo inexistente.');if(text.length>15000)throw new Error('El archivo de aula no puede superar 15 000 caracteres.');
 if(!['politica.json','candidatas.txt'].includes(file.name))throw new Error('Esta evidencia se consulta; no se edita.');
 const lab=next.labs[file.labId];
 if(file.name==='politica.json'){const c=validatePolicy(file.labId,text);if(lab.done.includes('vulnerable')){if(file.labId==='phishing'&&c.decision==='leave'||file.labId==='stuffing'&&c.reuse==='no'||file.labId==='dictionary'&&c.limit==='3'||file.labId==='recovery'&&c.factor==='on')completeTask(lab,'defense');}}
 if(file.name==='candidatas.txt'){const list=text.split(/\r?\n/).filter(x=>x.trim());if(!list.length||list.length>20||list.some(x=>x.length>80))throw new Error('Usa entre 1 y 20 candidatas de aula, una por línea, de hasta 80 caracteres.');}
 lab.files[file.name]=text.endsWith('\n')?text:text+'\n';return next;
}
export function shellPrompt(m){return m.context==='container'?`root@kali-aula:${m.cwd.replace(/^\/root(?=\/|$)/,'~')}#`:'estudiante@equipo:~$';}
function splitCommand(input){const tokens=input.match(/"[^"\n]*"|'[^'\n]*'|[^\s]+/g)||[];if((input.match(/"/g)||[]).length%2||(input.match(/'/g)||[]).length%2)throw new Error('Falta cerrar una comilla.');return tokens.map(t=>t.replace(/^(["'])(.*)\1$/,'$2'));}
function statusLine(r){return r.access==='Concedido'?'HTTP/1.1 200 OK · sesión de aula':r.access==='Restablecido'?'HTTP/1.1 200 OK · acceso restablecido':r.access?.startsWith('Pendiente')?'HTTP/1.1 403 MFA_REQUIRED':r.tone==='risk'?'HTTP/1.1 200 OK · muestra recibida':r.tone==='waiting'?'HTTP/1.1 202 PENDING':'HTTP/1.1 401 ACCESS_NOT_GRANTED';}
function recordResult(lab,result,label){lab.result=result;lab.runs.push({title:result.title,access:result.access,label});lab.runs=lab.runs.slice(-10);const log=[`PRUEBA ${lab.runs.length}: ${label}`,statusLine(result),...result.trace,`Resultado: ${result.title}`,`Acceso: ${result.access}`].join('\n');lab.files['evidencias.log']=(lab.files['evidencias.log']+'\n'+log+'\n').slice(-14000);return [statusLine(result),...result.trace,`→ ${result.title}`,result.detail];}
function fail(title,detail){return {tone:'safe',title,detail,asset:'No confirmado',access:'Rechazado',trace:[detail],done:true};}

export function executeCommand(machine,input){
 const m=structuredClone(machine),line=String(input).trim().slice(0,500),prompt=shellPrompt(m);let output=[],effect=null,tone='normal';
 const error=text=>{output=[text];tone='error';};
 try{
 if(!line)return {machine:m,output:[],effect:null};
 if(/[;&|<>`]/.test(line)||line.includes('$(')){throw new Error('La consola de aula acepta un comando a la vez, sin tuberías, redirecciones ni ejecución de scripts.');}
 const a=splitCommand(line),cmd=a[0],id=m.activeLab,lab=m.labs[id];
 if(cmd==='clear'){m.entries=[];effect={type:'clear'};}
 else if(['help','ayuda'].includes(cmd)){output=['CATÁLOGO DE LA CONSOLA DIDÁCTICA','Linux: pwd · ls · cd ruta · cat archivo · head archivo · whoami · uname -a · history · clear','Aplicaciones: mousepad archivo · firefox http://social.aula.test','Aula: aula iniciar caso · aula estado · aula ayuda','Casos: phishing · stuffing · dictionary · session · recovery','Docker: docker --version · docker images · docker ps · docker pull kalilinux/kali-rolling','Los comandos se interpretan en JavaScript. No hay una shell ni una red reales.'];}
 else if(cmd==='history')output=m.history.map((h,i)=>`${i+1}  ${h}`);
 else if(cmd==='whoami')output=[m.context==='container'?'root':'estudiante'];
 else if(cmd==='pwd')output=[m.cwd];
 else if(cmd==='uname'&&a[1]==='-a')output=['Linux kali-aula SIMULADO x86_64 GNU/Linux · comparte el kernel del anfitrión en el modelo Docker'];
 else if(cmd==='docker'){
  if(m.context==='container')throw new Error('docker: no está instalado dentro de este contenedor. Usa exit para volver al anfitrión.');
  if(a[1]==='--version'){output=['Docker Engine · simulación de comandos disponible'];if(m.stage===0)m.stage=1;}
  else if(a[1]==='pull'&&['kalilinux/kali-rolling','docker.io/kalilinux/kali-rolling'].includes(a[2])&&a.length===3){if(m.stage<1)throw new Error('Primero comprueba Docker con docker --version.');output=['Using default tag: latest','latest: Pulling from kalilinux/kali-rolling','Capa base: completada [simulada]','Sistema de archivos: preparado','Status: imagen de aula disponible'];m.stage=Math.max(m.stage,2);}
  else if(a.slice(1).join(' ')==='run -dit --name kali-aula kalilinux/kali-rolling bash'){if(m.stage<2)throw new Error('Imagen no disponible. Usa docker pull kalilinux/kali-rolling.');if(m.stage>=3)throw new Error('Conflict: el nombre kali-aula ya está en uso. Entra con docker exec -it kali-aula bash.');m.stage=3;output=['aula-container-042','Contenedor kali-aula: activo [simulado].'];}
  else if(a.slice(1).join(' ')==='exec -it kali-aula bash'){if(m.stage<3)throw new Error('No such container: kali-aula. Primero créalo con docker run.');m.context='container';m.cwd=m.stage===7?`${LAB_ROOT}/${m.activeLab}`:'/root';m.stage=Math.max(m.stage,4);output=['Conectado a la shell del contenedor kali-aula.'];}
  else if(a[1]==='images')output=['REPOSITORY                 TAG      ESTADO',...(m.stage>=2?['kalilinux/kali-rolling     latest   disponible [simulado]']:['(sin imágenes)'])];
  else if(a[1]==='ps')output=['CONTAINER ID       IMAGE                    STATUS   NAMES',...(m.stage>=3?['aula-042           kalilinux/kali-rolling   Up       kali-aula']:['(sin contenedores activos)'])];
  else throw new Error('Sintaxis Docker no incluida. Consulta la instrucción de la derecha o escribe ayuda.');
 }
 else if(cmd==='exit'){if(m.context==='container'){m.context='host';m.cwd='/home/estudiante';output=['Shell cerrada. El contenedor sigue activo.'];}else{effect={type:'close',window:'terminal'};output=['Terminal cerrada.'];}}
 else if(cmd==='apt'||cmd==='sudo'){
  const args=cmd==='sudo'?a.slice(1):a;if(m.context!=='container')throw new Error('Entra primero en Kali: docker exec -it kali-aula bash.');
  if(args.join(' ')==='apt update'){if(m.stage<4)throw new Error('El contenedor todavía no está disponible.');m.stage=Math.max(m.stage,5);output=['Get: repositorio kali-rolling [simulado]','Reading package lists... Done','Índices de aula actualizados.'];}
  else if(args.join(' ')==='apt install -y kali-desktop-xfce'){if(m.stage<5)throw new Error('Actualiza los índices con apt update.');m.stage=Math.max(m.stage,6);output=['Reading package lists... Done','Setting up xfce4-panel [simulado]','Setting up xfce4-terminal [simulado]','Setting up kali-desktop-xfce [simulado]','El lanzador aula escritorio abrirá la sesión gráfica didáctica.'];}
  else throw new Error('Este simulador solo representa apt update y apt install -y kali-desktop-xfce.');
 }
 else if(line==='aula escritorio'){if(m.context!=='container'||m.stage<6)throw new Error('Completa la instalación del escritorio dentro de Kali.');m.stage=7;m.cwd=`${LAB_ROOT}/${m.activeLab}`;output=['Sesión gráfica didáctica iniciada.','Carpeta de trabajo: '+m.cwd,'Usa la guía de la derecha. aula ayuda muestra las herramientas locales.'];effect={type:'desktop'};}
 else {
  if(m.stage<7)throw new Error('Completa primero la instalación guiada de la derecha.');
  if(m.context!=='container')throw new Error('Estás en el anfitrión. Entra con docker exec -it kali-aula bash.');
  if(cmd==='ls'){const path=pathFor(m,a.find((v,i)=>i>0&&!v.startsWith('-'))||'.');if(!directories().includes(path))throw new Error('ls: no existe ese directorio.');if(path===LAB_ROOT)output=WORKSHOPS.map(w=>w.id+'/');else if(path.startsWith(LAB_ROOT+'/'))output=Object.keys(m.labs[path.split('/').at(-1)].files);else output=directories().filter(d=>d.startsWith(path==='/'?'/':path+'/')&&d.slice(path==='/'?1:path.length+1).split('/').length===1).map(d=>d.split('/').at(-1)+'/');}
  else if(cmd==='cd'){const path=pathFor(m,a[1]||'~');if(!directories().includes(path))throw new Error('cd: directorio inexistente.');m.cwd=path;const dir=path.split('/').at(-1);if(BY_ID[dir])m.activeLab=dir;output=[];}
  else if(['cat','head'].includes(cmd)){const result=readVirtualFile(m,a[1]||'');if(result.error)throw new Error(result.error);m.labs=result.machine.labs;output=result.file.text.split('\n');if(cmd==='head')output=output.slice(0,10);}
  else if(cmd==='mousepad'){const file=resolveFile(m,a[1]||'');if(!file)throw new Error('mousepad: archivo inexistente. Usa ls para ver los archivos.');const read=readVirtualFile(m,file.path);m.labs=read.machine.labs;effect={type:'editor',path:file.path};output=['Abriendo '+file.path];}
  else if(cmd==='firefox'){if(a[1]&&!['http://social.aula.test','https://social.aula.test','social.aula.test'].includes(a[1]))throw new Error('Solo existe el servicio ficticio social.aula.test en este navegador de aula.');effect={type:'open',window:'browser'};output=['Navegador del laboratorio abierto.'];}
  else if(cmd==='aula'){
   const action=a[1];
   if(action==='iniciar'){if(!BY_ID[a[2]])throw new Error('Caso desconocido. Usa phishing, stuffing, dictionary, session o recovery.');m.activeLab=a[2];m.cwd=`${LAB_ROOT}/${a[2]}`;output=['Caso seleccionado: '+BY_ID[a[2]].name,'Archivos en '+m.cwd];}
   else if(action==='estado')output=WORKSHOPS.map(w=>`${w.name}: ${taskIndex(w.id,m.labs[w.id])}/${LAB_TASKS[w.id].length} tareas consecutivas completadas`);
   else if(['ayuda',undefined].includes(action))output=['HERRAMIENTA AULA · NO ES UN PROGRAMA REAL DE KALI','aula iniciar phishing|stuffing|dictionary|session|recovery','aula dominio dominio · aula phishing','aula acceso usuario clave · aula diccionario candidatas.txt','aula trafico https|http|proxy · aula sesion TOKEN · aula revocar','aula recuperar luna.crea · aula restablecer TOKEN','aula estado','Solo se procesan muestras y archivos virtuales locales.'];
   else {
    const c=validatePolicy(id,lab.files['politica.json']);let result;
    if(action==='dominio'){if(id!=='phishing')throw new Error('Selecciona el taller phishing.');if(a[2]!=='aula.invalid')throw new Error('Ese no es el dominio principal del enlace. Lee el final de la dirección completa.');completeTask(lab,'domain');output=['Correcto: aula.invalid controla este destino.','social.aula.test aparece a la izquierda como parte del subdominio.'];}
    else if(action==='phishing'){if(id!=='phishing')throw new Error('Selecciona el taller phishing.');result=evaluateScenario(id,c);if(result.tone==='risk')completeTask(lab,'vulnerable');if(lab.done.includes('defense')&&c.decision==='leave')completeTask(lab,'protected');}
    else if(action==='acceso'){if(id!=='stuffing')throw new Error('Selecciona el taller stuffing.');if(a.length!==4)throw new Error('Uso: aula acceso usuario contraseña');result=a[2]==='luna.crea'&&a[3]==='Luna!26'?evaluateScenario(id,c):fail('Par de muestra incorrecto','Consulta filtracion.csv. Esta actividad usa luna.crea y Luna!26.');if(result.access==='Concedido')completeTask(lab,'vulnerable');if(lab.done.includes('defense')&&c.reuse==='no'&&a[2]==='luna.crea'&&a[3]==='Luna!26')completeTask(lab,'protected');}
    else if(action==='diccionario'){
     if(id!=='dictionary')throw new Error('Selecciona el taller dictionary.');const file=resolveFile(m,a[2]||'');if(!file||file.labId!==id||file.name!=='candidatas.txt')throw new Error('Indica candidatas.txt en el directorio de este taller.');
     const list=file.text.split(/\r?\n/).map(x=>x.trim()).filter(Boolean),secret=c.target==='listed'?'Luna!26':'Mapa-cielo-nube-72',limit=Number(c.limit),trace=[];let found=false,paused=false;
     for(let i=0;i<list.length;i++){found=list[i]===secret;trace.push(`[${String(i+1).padStart(2,'0')}] ${list[i]} → ${found?'200 · coincidencia':'401 · no coincide'}`);if(found)break;if(limit&&i+1>=limit){paused=true;trace.push('429 · PAUSA DE ESTA RONDA');break;}}
     result={tone:found?'risk':'safe',title:found?'Candidata encontrada':paused?'Pausa tras fallos':'Lista agotada',detail:found?'La clave fue probada antes de detenerse.':paused?'Esta ronda terminó al alcanzar el límite. Una clave al principio podría acertar antes.':'Esta lista no encontró el secreto; no prueba invulnerabilidad.',asset:found?secret:'Ninguna contraseña confirmada',access:found?'Concedido':'Rechazado',trace,done:true};
     if(found&&limit===0)completeTask(lab,'vulnerable');if(lab.done.includes('defense')&&limit===3&&paused&&!found)completeTask(lab,'protected');
    }
    else if(action==='trafico'){if(id!=='session')throw new Error('Selecciona el taller session.');if(!['https','http','proxy'].includes(a[2]))throw new Error('Uso: aula trafico https|http|proxy');if(a[2]==='https'){completeTask(lab,'tls');output=lab.files['captura-https.txt'].split('\n');}else if(a[2]==='http'){completeTask(lab,'read');lab.exposed=true;output=lab.files['captura-http.txt'].split('\n');}else{result=evaluateScenario(id,{...c,channel:'proxy',revoked:lab.revoked?'yes':'no'});lab.exposed=lab.exposed||result.tone==='risk'||result.asset.includes('copia revocada');}effect={type:'open',window:'browser'};}
    else if(action==='sesion'){if(id!=='session')throw new Error('Selecciona el taller session.');if(a[2]!=='DEMO-SESION-042'||!lab.exposed)result=fail('Token no disponible o incorrecto','Primero observa una captura que exponga el token y escribe exactamente su valor.');else result=evaluateScenario(id,{...c,channel:'http',revoked:lab.revoked?'yes':'no'});if(result.access==='Concedido')completeTask(lab,'vulnerable');if(lab.done.includes('defense')&&lab.revoked&&lab.exposed&&a[2]==='DEMO-SESION-042')completeTask(lab,'protected');}
    else if(action==='revocar'){if(id!=='session')throw new Error('Selecciona el taller session.');lab.revoked=true;if(lab.done.includes('vulnerable'))completeTask(lab,'defense');output=['Sesión DEMO-SESION-042 revocada en el servidor de aula.','Las copias existentes ya no son aceptadas.'];}
    else if(action==='recuperar'){if(id!=='recovery')throw new Error('Selecciona el taller recovery.');if(a[2]!=='luna.crea')throw new Error('La cuenta de muestra es luna.crea.');lab.issued++;lab.token=`DEMO-RESET-${String(16+lab.issued).padStart(3,'0')}`;lab.consumed=false;lab.files['correo-recuperacion.txt']=`De: acceso@social.aula.test\nPara: luna@correo.aula.test\nAsunto: Recuperación de luna.crea\n\nToken de muestra: ${lab.token}\nUso: único. Estado: vigente.\n\nEste archivo es la bandeja virtual del laboratorio.\n`;completeTask(lab,'requested');if(lab.done.includes('defense'))completeTask(lab,'requestedAgain');output=['202 · Solicitud recibida.','Mensaje disponible en correo-recuperacion.txt'];effect={type:'open',window:'browser'};}
    else if(action==='restablecer'){if(id!=='recovery')throw new Error('Selecciona el taller recovery.');if(!lab.issued||a[2]!==lab.token)result=fail('Token inválido','Lee el correo actualizado. Cada solicitud reemplaza el enlace anterior.');else result=evaluateScenario(id,{...c,token:lab.consumed?'used':c.token});if(result.access==='Restablecido'){lab.consumed=true;completeTask(lab,'vulnerable');}if(lab.done.includes('requestedAgain')&&a[2]===lab.token&&c.factor==='on'&&c.mail==='yes'&&c.token==='valid'&&!lab.consumed)completeTask(lab,'protected');}
    else throw new Error('Acción de aula desconocida. Escribe aula ayuda.');
    if(result){output=recordResult(lab,result,line);effect={type:'open',window:'browser'};}
   }
  }else throw new Error(`${cmd}: comando no incluido. Escribe ayuda para consultar el catálogo.`);
 }
 }catch(e){error(e.message||'No se pudo interpretar el comando.');}
 if(line!=='clear'){m.sequence++;m.entries.push({id:m.sequence,prompt,input:line,output,tone});m.entries=m.entries.slice(-100);}m.history=[...m.history,line].slice(-100);
 return {machine:m,output,effect,tone};
}
