import { BY_ID, WORKSHOPS } from './content.js';
export const SCHEMA = 'acceso-lab-resultados-v2';
export function newAnswers(id) { const list=BY_ID[id].quiz.order.items.map(x=>x.id); return { single:'', order:[list[1],list[2],list[0]], orderConfirmed:false, matches:{} }; }
export function answerStatus(id, a) {
 const q=BY_ID[id]?.quiz;if(!q||!a)return [false,false,false];
 return [q.single.options.some(x=>x.id===a.single),Array.isArray(a.order)&&a.order.length===3&&new Set(a.order).size===3&&a.order.every(x=>q.order.items.some(i=>i.id===x))&&a.orderConfirmed===true,q.match.items.every(x=>q.match.targets.some(t=>t.id===a.matches?.[x.id]))];
}
export function grade(id,a) {
 if(!answerStatus(id,a).every(Boolean)) throw new Error('Completa las tres preguntas antes de calificar.');
 const q=BY_ID[id].quiz;
 const parts=[{points:a.single===q.single.correct?3:0,max:3},{points:a.order.filter((v,i)=>v===q.order.correct[i]).length,max:3},{points:q.match.items.filter(x=>a.matches[x.id]===x.correct).length,max:4}];
 return {parts,total:parts.reduce((n,x)=>n+x.points,0),max:10};
}
const clean=(v,n)=>typeof v==='string'?v.trim().slice(0,n):'';
export function validateRecord(raw) {
 if(!raw||!BY_ID[raw.workshopId]||!raw.student)throw new Error('El archivo contiene un taller o estudiante no válido.');
 const id=clean(raw.id,120),studentId=clean(raw.student.id,120),name=clean(raw.student.name,100),course=clean(raw.student.course,80);
 if(!id||!studentId||name.length<2||!course)throw new Error('Faltan los datos del estudiante.');
 if(typeof raw.date!=='string'||!Number.isFinite(Date.parse(raw.date)))throw new Error('El archivo contiene una fecha inválida.');
 const a=raw.answers;
 if(!answerStatus(raw.workshopId,a).every(Boolean))throw new Error('Hay respuestas incompletas o incompatibles.');
 const answers={single:a.single,order:[...a.order],orderConfirmed:true,matches:Object.fromEntries(BY_ID[raw.workshopId].quiz.match.items.map(i=>[i.id,a.matches[i.id]]))};
 return {id,student:{id:studentId,name,course},workshopId:raw.workshopId,date:new Date(raw.date).toISOString(),answers,...grade(raw.workshopId,answers)};
}
export function parseResults(text) {
 if(text.length>2_000_000)throw new Error('El archivo supera el límite de 2 MB.');
 let data;try{data=JSON.parse(text);}catch{throw new Error('Selecciona un archivo JSON de resultados generado por esta aplicación.');}
 if(data?.schema!==SCHEMA||!Array.isArray(data.records)||data.records.length>1000)throw new Error('Formato de resultados no compatible.');
 return data.records.map(validateRecord);
}
export function mergeRecords(existing,incoming) { const byId=new Map(existing.map(r=>[r.id,r]));for(const r of incoming){const old=byId.get(r.id);if(old&&JSON.stringify(old)!==JSON.stringify(r))throw new Error('Hay un resultado con el mismo identificador y contenido diferente. Conserva el original y revisa el archivo.');byId.set(r.id,r);}return [...byId.values()]; }
export function latestFor(records,studentId) { const map={};for(const r of records.filter(x=>x.student.id===studentId)){if(!map[r.workshopId]||Date.parse(r.date)>=Date.parse(map[r.workshopId].date))map[r.workshopId]=r;}return map; }
export function roster(records) { const ids=[...new Set(records.map(r=>r.student.id))];return ids.map(id=>{const latest=latestFor(records,id);const rows=Object.values(latest).sort((a,b)=>Date.parse(b.date)-Date.parse(a.date));const count=rows.length;return {student:rows[0].student,latest,count,average:count===5?Number((rows.reduce((s,r)=>s+r.total,0)/5).toFixed(2)):null};}); }
export function backup(records) { return JSON.stringify({schema:SCHEMA,exportedAt:new Date().toISOString(),records},null,2); }
export function csv(records) { const cell=v=>{let s=String(v??'');if(/^[=+\-@\t\r]/.test(s))s="'"+s;return '"'+s.replaceAll('"','""')+'"';};const header=['Estudiante','Curso',...WORKSHOPS.map(w=>w.name+' /10'),'Talleres completados','Promedio final /10'];const rows=roster(records).map(r=>[r.student.name,r.student.course,...WORKSHOPS.map(w=>r.latest[w.id]?.total??''),r.count,r.average===null?'':String(r.average).replace('.',',')]);return '\uFEFF'+[header,...rows].map(r=>r.map(cell).join(';')).join('\r\n'); }
export function responseLines(id,answers) {const q=BY_ID[id].quiz;const label=(items,value)=>items.find(x=>x.id===value)?.text||'Sin respuesta';return [
 {title:'1. Selección única',prompt:q.single.prompt,response:[label(q.single.options,answers.single)],correct:[label(q.single.options,q.single.correct)],explanation:q.single.explanation},
 {title:'2. Ordenamiento',prompt:q.order.prompt,response:answers.order.map((id,i)=>`${i+1}. ${label(q.order.items,id)}`),correct:q.order.correct.map((id,i)=>`${i+1}. ${label(q.order.items,id)}`),explanation:q.order.explanation},
 {title:'3. Relación de conceptos',prompt:q.match.prompt,response:q.match.items.map(i=>`${i.text}: ${label(q.match.targets,answers.matches[i.id])}`),correct:q.match.items.map(i=>`${i.text}: ${label(q.match.targets,i.correct)}`),explanation:'Un punto por cada relación correcta.'}
];}
