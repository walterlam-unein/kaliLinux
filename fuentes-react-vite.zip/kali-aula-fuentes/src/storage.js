import { BY_ID, WORKSHOPS } from './content.js';
import { newAnswers, parseResults, backup, latestFor } from './grading.js';

export const STORAGE_KEY='acceso-lab-aula-v2';
export const uid=()=>globalThis.crypto?.randomUUID?.()||`aula-${Date.now()}-${Math.random().toString(36).slice(2)}`;
export const newWork=id=>({sim:{step:0,attempt:0},observed:false,answers:newAnswers(id),recordId:null});
export const emptyState=()=>({student:null,work:{},records:[]});

export function readState(storage) {
 const empty=emptyState();
 try {
  const raw=storage?.getItem(STORAGE_KEY);if(!raw)return {data:empty,error:''};
  const saved=JSON.parse(raw);if(saved.version!==2)throw new Error();
  const records=parseResults(backup(saved.records||[]));
  const s=saved.student;
  const student=s&&typeof s.id==='string'&&typeof s.name==='string'&&typeof s.course==='string'&&s.name.trim().length>=2&&s.course.trim()?{id:s.id.slice(0,120),name:s.name.trim().slice(0,100),course:s.course.trim().slice(0,80)}:null;
  const work={};
  if(student)for(const w of WORKSHOPS){
   const draft=saved.work?.[w.id];if(!draft)continue;
   const fresh=newWork(w.id),a=draft.answers||{};
   const q=BY_ID[w.id].quiz;
   const validOrder=Array.isArray(a.order)&&a.order.length===3&&new Set(a.order).size===3&&a.order.every(x=>q.order.items.some(i=>i.id===x));
   fresh.answers={single:q.single.options.some(x=>x.id===a.single)?a.single:'',order:validOrder?[...a.order]:fresh.answers.order,orderConfirmed:validOrder&&a.orderConfirmed===true,matches:Object.fromEntries(q.match.items.filter(i=>q.match.targets.some(t=>t.id===a.matches?.[i.id])).map(i=>[i.id,a.matches[i.id]]))};
   fresh.sim={step:Math.min(5,Math.max(0,Number.isInteger(draft.sim?.step)?draft.sim.step:0)),attempt:Math.min(5,Math.max(0,Number.isInteger(draft.sim?.attempt)?draft.sim.attempt:0))};
   fresh.observed=draft.observed===true||fresh.sim.step===5;
   const record=records.find(r=>r.id===draft.recordId&&r.student.id===student.id&&r.workshopId===w.id);
   if(record){fresh.recordId=record.id;fresh.answers=record.answers;fresh.observed=true;}
   work[w.id]=fresh;
  }
  return {data:{student,work,records},error:''};
 }catch{return {data:empty,error:'No se pudo leer el progreso guardado. Puedes importar un respaldo JSON desde «Notas /10». Guarda un respaldo al terminar.'};}
}
export function workFromRecords(records,studentId){return Object.fromEntries(Object.entries(latestFor(records,studentId)).map(([id,r])=>[id,{sim:{step:5,attempt:0},observed:true,answers:r.answers,recordId:r.id}]));}
export function persist(storage,data){storage.setItem(STORAGE_KEY,JSON.stringify({version:2,...data}));}
