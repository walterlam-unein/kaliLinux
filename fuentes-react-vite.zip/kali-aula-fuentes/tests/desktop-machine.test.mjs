import test from 'node:test';
import assert from 'node:assert/strict';
import {newMachine,executeCommand,selectLab,saveVirtualFile,resolveFile,loadMachine,MACHINE_KEY} from '../src/os/machine.js';
import {INSTALL_STEPS,LAB_ROOT,LAB_TASKS,taskIndex} from '../src/os/labFiles.js';
const run=(m,c)=>executeCommand(m,c).machine;
const ready=()=>INSTALL_STEPS.reduce((m,s)=>run(m,s[2]),newMachine());
const policy=(m,patch)=>{const path=`${LAB_ROOT}/${m.activeLab}/politica.json`;return saveVirtualFile(m,path,JSON.stringify({...JSON.parse(resolveFile(m,path).text),...patch}));};
const done=(m,id)=>assert.equal(taskIndex(id,m.labs[id]),LAB_TASKS[id].length);
test('La preparación exige imagen, contenedor, shell y paquetes en orden',()=>{
 let m=newMachine();assert.equal(run(m,'aula escritorio').stage,0);assert.equal(run(m,'docker exec -it kali-aula bash').context,'host');
 for(const [i,s] of INSTALL_STEPS.entries()){m=run(m,s[2]);assert.equal(m.stage,i+1);}
 assert.equal(m.context,'container');assert.match(m.cwd,/phishing$/);m=run(m,'exit');assert.equal(m.context,'host');assert.match(executeCommand(m,'aula phishing').output.join(' '),/anfitrión/);m=run(m,'docker exec -it kali-aula bash');assert.equal(m.stage,7);
});
test('Phishing: dominio incorrecto, entrega y retirada verificables',()=>{
 let m=ready();m=run(m,'cat mensaje.txt');m=run(m,'aula dominio social.aula.test');assert.equal(taskIndex('phishing',m.labs.phishing),1);m=run(m,'aula dominio aula.invalid');m=run(m,'aula phishing');assert.equal(m.labs.phishing.result.tone,'risk');m=policy(m,{decision:'leave'});m=run(m,'aula phishing');assert.equal(m.labs.phishing.result.tone,'safe');done(m,'phishing');
});
test('Credential stuffing: mismo par conocido y nueva contraseña social',()=>{
 let m=selectLab(ready(),'stuffing');m=run(m,'cat filtracion.csv');m=run(m,'aula acceso luna.crea equivocada');assert.equal(m.labs.stuffing.result.access,'Rechazado');m=run(m,'aula acceso luna.crea Luna!26');assert.equal(m.labs.stuffing.result.access,'Concedido');m=policy(m,{reuse:'no'});m=run(m,'aula acceso luna.crea Luna!26');assert.equal(m.labs.stuffing.result.access,'Rechazado');done(m,'stuffing');
});
test('Diccionario: el límite y el archivo editado cambian los intentos reales del modelo',()=>{
 let m=selectLab(ready(),'dictionary');m=run(m,'cat candidatas.txt');m=run(m,'aula diccionario candidatas.txt');assert.equal(m.labs.dictionary.result.trace.length,5);assert.equal(m.labs.dictionary.result.access,'Concedido');m=policy(m,{limit:'3'});m=run(m,'aula diccionario candidatas.txt');assert.equal(m.labs.dictionary.result.title,'Pausa tras fallos');assert.equal(m.labs.dictionary.result.trace.length,4);done(m,'dictionary');m=saveVirtualFile(m,'candidatas.txt','Luna!26\notra\n');m=run(m,'aula diccionario candidatas.txt');assert.equal(m.labs.dictionary.result.trace.length,1);assert.equal(m.labs.dictionary.result.access,'Concedido');
});
test('Sesión: TLS no expone la cookie; HTTP, reutilización y revocación',()=>{
 let m=selectLab(ready(),'session');m=run(m,'aula trafico https');m=run(m,'aula sesion DEMO-SESION-042');assert.equal(m.labs.session.result.access,'Rechazado');m=run(m,'aula trafico http');m=run(m,'aula trafico https');assert.equal(m.labs.session.exposed,true,'TLS no revoca una copia obtenida previamente');m=run(m,'aula sesion DEMO-SESION-042');assert.equal(m.labs.session.result.access,'Concedido');m=run(m,'aula revocar');m=run(m,'aula sesion DEMO-SESION-042');assert.equal(m.labs.session.result.access,'Rechazado');done(m,'session');
});
test('Recuperación: tokens nuevos, un solo uso y prueba independiente',()=>{
 let m=selectLab(ready(),'recovery');m=run(m,'aula recuperar luna.crea');m=run(m,'cat correo-recuperacion.txt');const t=m.labs.recovery.token;m=run(m,`aula restablecer ${t}`);assert.equal(m.labs.recovery.result.access,'Restablecido');m=run(m,`aula restablecer ${t}`);assert.equal(m.labs.recovery.result.access,'No restablecido');m=policy(m,{factor:'on'});m=run(m,'aula recuperar luna.crea');assert.notEqual(m.labs.recovery.token,t);m=run(m,`aula restablecer ${t}`);assert.equal(m.labs.recovery.result.title,'Token inválido');m=run(m,`aula restablecer ${m.labs.recovery.token}`);assert.equal(m.labs.recovery.result.access,'No restablecido');done(m,'recovery');
});
test('Archivos virtuales: rutas, validación y persistencia sin ejecutar scripts',()=>{
 let m=ready();m=run(m,'cd ../dictionary');assert.equal(m.activeLab,'dictionary');assert.match(executeCommand(m,'ls').output.join(' '),/candidatas/);assert.throws(()=>saveVirtualFile(m,'politica.json','{"limit":'),/JSON inválido/);assert.throws(()=>policy(m,{limit:'99'}),/Valor inválido/);assert.throws(()=>saveVirtualFile(m,'candidatas.txt',''),/entre 1 y 20/);assert.throws(()=>saveVirtualFile(m,'LEEME.txt','x'),/no se edita/);for(const c of ['ls; whoami','cat /etc/passwd','firefox https://instagram.com','curl https://example.com'])assert.equal(executeCommand(m,c).tone,'error');const storage={getItem:key=>key===MACHINE_KEY?JSON.stringify(m):null};assert.deepEqual(loadMachine(storage),m);assert.equal(loadMachine({getItem:()=>'{broken'}).stage,0);
});
