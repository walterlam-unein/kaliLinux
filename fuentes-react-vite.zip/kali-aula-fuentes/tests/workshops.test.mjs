import test,{after} from 'node:test';
import assert from 'node:assert/strict';
import { mkdirSync,writeFileSync,unlinkSync } from 'node:fs';
import { buildSync } from 'esbuild';
import React from 'react';
import { act,create } from 'react-test-renderer';
import { WORKSHOPS } from '../src/content.js';
import { newAnswers,grade,parseResults,backup,mergeRecords,roster,validateRecord,csv } from '../src/grading.js';
import { readState,persist,STORAGE_KEY,newWork } from '../src/storage.js';
import { makeQuestionPdf,makeGradesPdf } from '../src/reports.js';

globalThis.IS_REACT_ACT_ENVIRONMENT=true;
buildSync({stdin:{contents:"export {App} from './src/App.jsx'; export {Simulation} from './src/Simulation.jsx'; export {Questions} from './src/Questions.jsx'; export {Kali} from './src/Kali.jsx'; export {Experiment} from './src/Experiment.jsx'; export {Configuration} from './src/Configuration.jsx';",resolveDir:process.cwd(),loader:'jsx'},outfile:'tests/.components.mjs',bundle:true,platform:'node',format:'esm',packages:'external'});
const {App,Simulation,Questions,Kali,Experiment,Configuration}=await import('./.components.mjs');
after(()=>unlinkSync('tests/.components.mjs'));
const student={id:'student-demo',name:'María José Álvarez',course:'2.º BGU · B'};
const fullAnswers=w=>({single:w.quiz.single.correct,order:[...w.quiz.order.correct],orderConfirmed:true,matches:Object.fromEntries(w.quiz.match.items.map(i=>[i.id,i.correct]))});
const record=(w,n=0)=>validateRecord({id:`result-${w.id}-${n}`,student,workshopId:w.id,date:new Date(Date.UTC(2026,9,20,12,n)).toISOString(),answers:fullAnswers(w)});
const records=WORKSHOPS.map(w=>record(w));
const text=n=>typeof n==='string'?n:(n?.children||[]).map(text).join('');
const button=(r,label)=>r.root.findAllByType('button').find(b=>text(b)===label);
const memory=()=>{const data=new Map();return {getItem:k=>data.get(k)||null,setItem:(k,v)=>data.set(k,v)};};

test('Los cinco talleres califican 3 + 3 + 4; no aceptan respuestas incompletas',()=>{
 for(const w of WORKSHOPS){assert.equal(grade(w.id,fullAnswers(w)).total,10);assert.throws(()=>grade(w.id,newAnswers(w.id)));const a=fullAnswers(w);a.single=w.quiz.single.options.find(o=>o.id!==a.single).id;assert.equal(grade(w.id,a).total,7);[a.order[0],a.order[1]]=[a.order[1],a.order[0]];assert.equal(grade(w.id,a).total,5);}
});
test('La importación recalcula la nota, rechaza datos inválidos y evita duplicados',()=>{
 const forged={...records[0],total:999};const incoming=parseResults(backup([forged]));assert.equal(incoming[0].total,10);assert.equal(mergeRecords(records,incoming).length,5);assert.throws(()=>parseResults('{bad'));assert.throws(()=>parseResults(backup([{...forged,answers:{}}])));assert.throws(()=>mergeRecords(records,[{...records[0],student:{...student,name:'Otra persona'}}]));
});
test('El promedio espera cinco notas y usa el último intento; CSV válido para Excel',()=>{
 assert.equal(roster(records.slice(0,4))[0].average,null);assert.equal(roster(records)[0].average,10);const newer=record(WORKSHOPS[0],1);newer.answers.single='a';const updated=validateRecord(newer);assert.equal(roster([...records,updated])[0].average,9.4);assert.match(csv(records),/Promedio final/);assert.match(csv([{...records[0],student:{...student,name:'=2+2'}}]),/'=2\+2/);
});
test('El progreso vuelve a cargar y el JSON corrupto no rompe la página',()=>{
 const s=memory(),work={phishing:{...newWork('phishing'),sim:{step:2,attempt:0}}};persist(s,{student,work,records});assert.equal(readState(s).data.work.phishing.sim.step,2);s.setItem(STORAGE_KEY,'malformado');assert.ok(readState(s).error);
});
for(const w of WORKSHOPS)test(`Simulador ${w.name}: una acción por paso y acceso a preguntas`,async()=>{
 let state={step:0,attempt:0},questions=0,renderer;
 const draw=()=>React.createElement(Simulation,{workshop:w,state,onChange:s=>{state=s;renderer.update(draw());},onQuestions:()=>questions++});
 await act(()=>{renderer=create(draw());});let clicks=0;
 while(state.step<5){const actions=renderer.root.findAllByType('button').filter(b=>b.props.className?.startsWith('social-action'));assert.equal(actions.length,1);assert.equal(text(actions[0]),w.steps[state.step][2]);await act(()=>actions[0].props.onClick());assert.ok(++clicks<20);}
 assert.equal(clicks,w.id==='dictionary'?11:5);await act(()=>button(renderer,'Ir a las preguntas').props.onClick());assert.equal(questions,1);await act(()=>renderer.unmount());
});
test('Tres estilos de preguntas: seleccionar, reordenar, relacionar y calificar',async()=>{
 const w=WORKSHOPS[0];let a=newAnswers(w.id),submitted=false,renderer;
 const draw=()=>React.createElement(Questions,{workshop:w,answers:a,onChange:value=>{a=value;renderer.update(draw());},onSubmit:()=>submitted=true});
 await act(()=>{renderer=create(draw());});assert.ok(button(renderer,'Calificar y ver mi reporte').props.disabled);
 await act(()=>renderer.root.findAllByType('input').find(i=>i.props.value===w.quiz.single.correct).props.onChange());
 await act(()=>renderer.root.findByProps({'aria-label':'Subir paso 3'}).props.onClick());
 await act(()=>renderer.root.findByProps({'aria-label':'Subir paso 2'}).props.onClick());
 await act(()=>button(renderer,'Confirmar mi orden').props.onClick());
 for(const item of w.quiz.match.items)await act(()=>renderer.root.findByProps({'aria-label':`Relacionar ${item.text}`}).props.onChange({target:{value:item.correct}}));
 assert.equal(button(renderer,'Calificar y ver mi reporte').props.disabled,false);await act(()=>button(renderer,'Calificar y ver mi reporte').props.onClick());assert.equal(submitted,true);assert.equal(grade(w.id,a).total,10);await act(()=>renderer.unmount());
});
test('Flujo completo: perfil, simulador, evaluación, reporte, notas y persistencia',async()=>{
 const storage=memory();let app;await act(()=>{app=create(React.createElement(App,{storage,configuration:{courseName:'2.º BGU'}}));});
 assert.ok(app.root.findAllByType('button').find(b=>b.props['aria-label']==='Abrir taller: Phishing').props.disabled);
 await act(()=>app.root.findByProps({placeholder:'Ej. Andrea M.'}).props.onChange({target:{value:'Ana Prueba'}}));
 await act(()=>app.root.findByType('form').props.onSubmit({preventDefault(){}}));
 await act(()=>app.root.findByProps({'aria-label':'Abrir taller: Phishing'}).props.onClick());
 for(let i=0;i<6;i++)await act(()=>app.root.findAllByType('button').find(b=>b.props.className?.startsWith('social-action')).props.onClick());
 const w=WORKSHOPS[0];await act(()=>app.root.findAllByType('input').find(i=>i.props.value===w.quiz.single.correct).props.onChange());
 await act(()=>app.root.findByProps({'aria-label':'Subir paso 3'}).props.onClick());await act(()=>app.root.findByProps({'aria-label':'Subir paso 2'}).props.onClick());await act(()=>button(app,'Confirmar mi orden').props.onClick());
 for(const item of w.quiz.match.items)await act(()=>app.root.findByProps({'aria-label':`Relacionar ${item.text}`}).props.onChange({target:{value:item.correct}}));
 await act(()=>button(app,'Calificar y ver mi reporte').props.onClick());assert.ok(button(app,'Descargar respuestas en PDF'));assert.equal(readState(storage).data.records[0].total,10);
 await act(()=>button(app,'Ver mis notas /10').props.onClick());assert.ok(button(app,'Descargar notas en PDF'));assert.match(text(app.root),/1\/5 completados/);await act(()=>app.unmount());
 await act(()=>{app=create(React.createElement(App,{storage}));});assert.ok(app.root.findByProps({'aria-label':'Ver reporte: Phishing'}));await act(()=>app.unmount());
});
test('Los reportes PDF incluyen las tres preguntas y generan páginas',()=>{
 mkdirSync('qa',{recursive:true});for(const r of records){const doc=makeQuestionPdf(r);assert.ok(doc.getNumberOfPages()>=1);writeFileSync(`qa/respuestas-${r.workshopId}.pdf`,Buffer.from(doc.output('arraybuffer')));}
 writeFileSync('qa/notas.pdf',Buffer.from(makeGradesPdf(records).output('arraybuffer')));
});


test('Kali permite explorar el escritorio, el alcance y el mapa sin registrarse',async()=>{
 let renderer,chosen;await act(()=>{renderer=create(React.createElement(Kali,{onHome(){},onWorkshop:id=>chosen=id,hasStudent:true}));});
 assert.match(text(renderer.root),/distribución de Linux basada en Debian/);
 await act(()=>button(renderer,'El alcance').props.onClick());await act(()=>button(renderer,'Cuenta ajena sin autorización').props.onClick());assert.match(text(renderer.root),/Fuera del alcance/);
 await act(()=>button(renderer,'El método').props.onClick());for(let i=0;i<3;i++)await act(()=>button(renderer,'Siguiente etapa').props.onClick());assert.ok(button(renderer,'Elegir un taller'));
 await act(()=>button(renderer,'Credential stuffing').props.onClick());await act(()=>button(renderer,'Abrir este taller').props.onClick());assert.equal(chosen,'stuffing');await act(()=>renderer.unmount());
});

test('Experimentar cambia el resultado, invalida datos anteriores y compara pruebas',async()=>{
 let renderer;const w=WORKSHOPS.find(w=>w.id==='stuffing');await act(()=>{renderer=create(React.createElement(Experiment,{workshop:w,onGuided(){}}));});
 await act(()=>button(renderer,'Probar par conocido').props.onClick());assert.match(text(renderer.root),/Sesión concedida por reutilización/);
 await act(()=>renderer.root.findByProps({'aria-label':'Segundo factor independiente'}).props.onChange({target:{value:'on'}}));
 assert.equal(renderer.root.findAll(n=>n.props.className?.startsWith('experiment-result')).length,0);
 await act(()=>button(renderer,'Probar par conocido').props.onClick());assert.match(text(renderer.root),/Falta el segundo factor/);
 const history=renderer.root.findByProps({className:'comparison-list'});assert.equal(history.findAllByType('article').length,2);await act(()=>renderer.unmount());
});

test('El diccionario desactiva intentos al llegar al límite y permite cambiar el caso',async()=>{
 let renderer;const w=WORKSHOPS.find(w=>w.id==='dictionary');await act(()=>{renderer=create(React.createElement(Experiment,{workshop:w,onGuided(){}}));});
 for(let i=0;i<3;i++)await act(()=>button(renderer,'Probar siguiente candidata').props.onClick());assert.equal(button(renderer,'Probar siguiente candidata').props.disabled,true);
 await act(()=>renderer.root.findByProps({'aria-label':'Orden de las candidatas'}).props.onChange({target:{value:'first'}}));assert.equal(button(renderer,'Probar siguiente candidata').props.disabled,undefined);
 await act(()=>button(renderer,'Probar siguiente candidata').props.onClick());assert.match(text(renderer.root),/La candidata coincidió/);await act(()=>renderer.unmount());
});

test('Ajustes guardados cambian módulos y se restauran al abrir la aplicación',async()=>{
 const storage=memory();let app;await act(()=>{app=create(React.createElement(App,{storage}));});
 await act(()=>app.root.findByProps({'aria-label':'Ajustes de aula'}).props.onClick());
 const boxes=app.root.findAllByType('input').filter(n=>n.props.type==='checkbox');await act(()=>boxes[1].props.onChange({target:{checked:false}}));
 await act(()=>app.root.findByProps({'aria-label':'Docente o encabezado'}).props.onChange({target:{value:'Aula de prueba'}}));
 await act(()=>app.root.findByType('form').props.onSubmit({preventDefault(){}}));assert.match(text(app.root),/Ajustes aplicados y guardados/);
 await act(()=>button(app,'Volver a talleres').props.onClick());assert.equal(button(app,'Explorar Kali Linux'),undefined);assert.match(text(app.root),/Aula de prueba/);await act(()=>app.unmount());
 await act(()=>{app=create(React.createElement(App,{storage}));});assert.equal(button(app,'Kali Linux'),undefined);assert.match(text(app.root),/Aula de prueba/);await act(()=>app.unmount());
});
