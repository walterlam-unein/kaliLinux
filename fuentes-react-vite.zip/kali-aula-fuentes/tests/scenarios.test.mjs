import test from 'node:test';
import assert from 'node:assert/strict';
import { evaluateScenario,normalizeScenario,scenarioLabel } from '../src/scenarioEngine.js';
import { configurationFile,readConfiguration,CONFIG_KEY } from '../src/configuration.js';

test('Phishing: el candado no cambia al destinatario y salir evita la entrega',()=>{
 for(const tls of ['yes','no'])assert.equal(evaluateScenario('phishing',{destination:'fake',decision:'send',tls}).tone,'risk');
 assert.equal(evaluateScenario('phishing',{decision:'leave'}).asset,'Ninguna credencial recibida');
 assert.equal(evaluateScenario('phishing',{destination:'known',tls:'yes'}).tone,'safe');
 assert.equal(evaluateScenario('phishing',{destination:'known',tls:'no'}).tone,'caution');
});
test('Stuffing: distingue clave incorrecta de segundo factor pendiente',()=>{
 assert.equal(evaluateScenario('stuffing',{reuse:'yes',mfa:'off'}).access,'Concedido');
 assert.equal(evaluateScenario('stuffing',{reuse:'yes',mfa:'on'}).access,'Pendiente: no concedido');
 assert.equal(evaluateScenario('stuffing',{reuse:'no',mfa:'off'}).access,'Rechazado');
});
test('Diccionario: las 12 combinaciones respetan aciertos, lista y pausa',()=>{
 for(const target of ['listed','absent'])for(const order of ['first','last'])for(const limit of ['0','3','5']){
  const result=evaluateScenario('dictionary',{target,order,limit},99);
  const hit=target==='listed'&&(order==='first'||limit!=='3');
  assert.equal(result.state==='hit',hit);
  assert.ok(result.trials.length<=5);assert.ok(limit==='0'||result.trials.length<=Number(limit));
  if(hit)assert.equal(result.trials.at(-1).hit,true);
  assert.equal(result.done,true);
 }
 assert.equal(evaluateScenario('dictionary',{},1).done,false);
});
test('Sesión: TLS válido, proxy con código, passkey y revocación son casos distintos',()=>{
 assert.equal(evaluateScenario('session',{channel:'tls'}).access,'No concedido');
 assert.equal(evaluateScenario('session',{channel:'http',revoked:'no'}).access,'Concedido');
 assert.equal(evaluateScenario('session',{channel:'http',revoked:'yes'}).access,'Rechazado');
 assert.equal(evaluateScenario('session',{channel:'proxy',factor:'otp',revoked:'no'}).access,'Concedido');
 assert.equal(evaluateScenario('session',{channel:'proxy',factor:'passkey'}).access,'No concedido');
 assert.equal(evaluateScenario('session',{channel:'proxy',factor:'otp',revoked:'yes'}).access,'Rechazado');
 assert.ok(!scenarioLabel('session',normalizeScenario('session')).includes('código copiable'));
});
test('Recuperación: solo el enlace válido con buzón controlado y sin otra prueba permite cambio',()=>{
 for(const mail of ['yes','no'])for(const token of ['valid','expired','used'])for(const factor of ['on','off']){
  const result=evaluateScenario('recovery',{mail,token,factor});
  assert.equal(result.access==='Restablecido',mail==='yes'&&token==='valid'&&factor==='off');
 }
});
test('Los escenarios descartan condiciones desconocidas y la configuración exporta datos',()=>{
 assert.deepEqual(normalizeScenario('stuffing',{reuse:'extraño',mfa:'<script>'}),{reuse:'yes',mfa:'off'});
 assert.throws(()=>evaluateScenario('other',{}));
 const value={courseName:'2.º BGU',teacherName:'Aula "Prueba"',projector:true,showKali:false,showExperiments:true};
 const script=configurationFile(value),json=script.slice(script.indexOf('=')+1).trim().slice(0,-1);assert.deepEqual(JSON.parse(json),value);
 assert.deepEqual(readConfiguration({getItem:k=>k===CONFIG_KEY?JSON.stringify(value):null}),value);
 assert.equal(readConfiguration({getItem:()=>'{invalid'}).showKali,true);
});
