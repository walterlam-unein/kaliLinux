import test,{after} from 'node:test';
import assert from 'node:assert/strict';
import {unlinkSync} from 'node:fs';
import {buildSync} from 'esbuild';
import React from 'react';
import {act,create} from 'react-test-renderer';
import {INSTALL_STEPS} from '../src/os/labFiles.js';
import {MACHINE_KEY} from '../src/os/machine.js';
import {readState} from '../src/storage.js';
import {WORKSHOPS} from '../src/content.js';
globalThis.IS_REACT_ACT_ENVIRONMENT=true;
buildSync({stdin:{contents:"export {Desktop} from './src/os/Desktop.jsx';",resolveDir:process.cwd(),loader:'jsx'},outfile:'tests/.desktop.mjs',bundle:true,platform:'node',format:'esm',packages:'external'});
const {Desktop}=await import('./.desktop.mjs');after(()=>unlinkSync('tests/.desktop.mjs'));
const memory=()=>{const data=new Map();return {getItem:k=>data.get(k)||null,setItem:(k,v)=>data.set(k,v)};};
const text=n=>typeof n==='string'?n:(n?.children||[]).map(text).join('');
const button=(r,label)=>r.root.findAllByType('button').find(b=>text(b)===label);
const windowOf=(r,name)=>r.root.findByProps({role:'dialog','aria-label':name});
const command=async(r,line)=>{await act(()=>r.root.findByProps({'aria-label':'Comando de terminal'}).props.onChange({target:{value:line}}));await act(()=>r.root.findByProps({className:'terminal-input-line'}).props.onSubmit({preventDefault(){}}));};

test('Escritorio: instalar escribiendo, editar, calificar, cerrar y recuperar reportes',async()=>{
 const storage=memory();let r;await act(()=>{r=create(React.createElement(Desktop,{storage,configuration:{courseName:'2.º BGU'}}));});
 try{
 assert.equal(button(r,'Abrir preguntas3 preguntas · 10 puntos').props.disabled,true);
 await act(()=>r.root.findByProps({'aria-label':'Cerrar Terminal'}).props.onClick());assert.equal(windowOf(r,'Terminal').props.hidden,true);await act(()=>r.root.findByProps({'aria-label':'Abrir Terminal'}).props.onClick());assert.equal(windowOf(r,'Terminal').props.hidden,false);
 for(const step of INSTALL_STEPS)await command(r,step[2]);assert.match(r.root.findByProps({className:'os-root kali-ready '}).props.className,/kali-ready/);assert.equal(windowOf(r,'Docker — equipo anfitrión').props.hidden,true);
 for(const line of ['cat mensaje.txt','aula dominio aula.invalid','aula phishing','mousepad politica.json'])await command(r,line);
 assert.equal(windowOf(r,'Mousepad').props.hidden,false);let editor=r.root.findByProps({'aria-label':'Contenido de politica.json'});const edited=editor.props.value.replace('"send"','"leave"');await act(()=>editor.props.onChange({target:{value:edited}}));
 await act(()=>r.root.findByProps({'aria-label':'Cerrar Mousepad'}).props.onClick());await command(r,'mousepad politica.json');assert.equal(r.root.findByProps({'aria-label':'Contenido de politica.json'}).props.value,edited);await act(()=>button(r,'Guardar').props.onClick());await command(r,'aula phishing');
 assert.equal(button(r,'Abrir preguntas3 preguntas · 10 puntos').props.disabled,false);await act(()=>r.root.findByProps({'aria-label':'Identificación del estudiante'}).props.onClick());await act(()=>r.root.findByProps({'aria-label':'Nombre o alias del estudiante'}).props.onChange({target:{value:'Estudiante de prueba'}}));await act(()=>windowOf(r,'Identificación').findByType('form').props.onSubmit({preventDefault(){}}));
 await act(()=>button(r,'Abrir preguntas3 preguntas · 10 puntos').props.onClick());assert.equal(windowOf(r,'Preguntas del taller').props.hidden,false);
 const w=WORKSHOPS[0];await act(()=>r.root.findAllByType('input').find(i=>i.props.value===w.quiz.single.correct&&i.props.type==='radio').props.onChange());await act(()=>r.root.findByProps({'aria-label':'Subir paso 3'}).props.onClick());await act(()=>r.root.findByProps({'aria-label':'Subir paso 2'}).props.onClick());await act(()=>button(r,'Confirmar mi orden').props.onClick());for(const item of w.quiz.match.items)await act(()=>r.root.findByProps({'aria-label':`Relacionar ${item.text}`}).props.onChange({target:{value:item.correct}}));await act(()=>button(r,'Calificar y ver mi reporte').props.onClick());assert.equal(readState(storage).data.records[0].total,10);assert.equal(windowOf(r,'Reporte del taller').props.hidden,false);
 await act(()=>button(r,'Cerrar reporteNota guardada: 10/10').props.onClick());assert.equal(windowOf(r,'Reporte del taller').props.hidden,true);await act(()=>button(r,'Abrir reporte del tallerNota guardada: 10/10').props.onClick());assert.equal(windowOf(r,'Reporte del taller').props.hidden,false);await act(()=>button(r,'Todas las notas /10PDF, CSV e importación JSON').props.onClick());assert.equal(windowOf(r,'Registro de notas').props.hidden,false);await act(()=>button(r,'Cerrar registroPDF, CSV e importación JSON').props.onClick());assert.equal(windowOf(r,'Registro de notas').props.hidden,true);
 }finally{await act(()=>r.unmount());}
 await act(()=>{r=create(React.createElement(Desktop,{storage}));});try{assert.equal(readState(storage).data.records.length,1);assert.equal(JSON.parse(storage.getItem(MACHINE_KEY)).stage,7);assert.ok(button(r,'Abrir reporte del tallerNota guardada: 10/10'));}finally{await act(()=>r.unmount());}
});

test('Cambiar estudiante conserva notas previas y limpia las evidencias de la práctica',async()=>{
 const storage=memory();let r;await act(()=>{r=create(React.createElement(Desktop,{storage,configuration:{courseName:'BGU'}}));});try{
 for(const step of INSTALL_STEPS)await command(r,step[2]);
 for(const name of ['Primer estudiante','Segundo estudiante']){await act(()=>r.root.findByProps({'aria-label':'Identificación del estudiante'}).props.onClick());await act(()=>r.root.findByProps({'aria-label':'Nombre o alias del estudiante'}).props.onChange({target:{value:name}}));await act(()=>windowOf(r,'Identificación').findByType('form').props.onSubmit({preventDefault(){}}));if(name==='Primer estudiante')await command(r,'cat mensaje.txt');}
 const m=JSON.parse(storage.getItem(MACHINE_KEY));assert.equal(m.stage,7);assert.equal(m.labs.phishing.done.length,0);assert.equal(readState(storage).data.student.name,'Segundo estudiante');
 }finally{await act(()=>r.unmount());}
});
