import { defineConfig } from 'vite';
import { readFileSync, writeFileSync } from 'node:fs';

// IIFE: React se incluye en app.js; la página compilada también abre con file://.
export default defineConfig({
  base: './',
  define: { 'process.env.NODE_ENV': JSON.stringify('production') },
  build: {
    lib: { entry: 'src/main.jsx', name: 'AccesoLab', formats: ['iife'], fileName: () => 'app.js' },
    cssCodeSplit: false,
    rollupOptions: { output: { assetFileNames: 'styles.css', inlineDynamicImports: true } },
  },
  plugins: [{
    name: 'standalone-page',
    apply: 'build',
    closeBundle() {
      const html = readFileSync('index.html', 'utf8')
        .replace('<head>', '<head>\n<meta http-equiv="Content-Security-Policy" content="default-src \'self\' data:; script-src \'self\'; style-src \'self\' \'unsafe-inline\'; img-src \'self\' data:; connect-src \'none\'; form-action \'none\'; object-src \'none\'; base-uri \'self\'">')
        .replace('</head>', '<link rel="stylesheet" href="./styles.css"></head>')
        .replace('<script type="module" src="./src/main.jsx"></script>', '<script defer src="./app.js"></script>');
      writeFileSync('dist/index.html', html);
    }
  }]
});
